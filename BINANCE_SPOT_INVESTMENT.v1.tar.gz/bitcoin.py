import ccxt
import json
import time
import logging
from datetime import datetime
import pytz
from schedule import Scheduler

# Load configuration
with open('config.json') as f:
    config = json.load(f)

# Binance setup for SPOT market
exchange = ccxt.binance({
    "apiKey": config["apiKey"],
    "secret": config["secretKey"],
    'options': {
        'defaultType': 'spot'  # Ensures all trades occur in the SPOT market
    },
    'enableRateLimit': True
})

# Configure logging with IST timezone
log_file = "investment_bot.log"
logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(funcName)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
console_handler.setFormatter(console_formatter)
logging.getLogger().addHandler(console_handler)

# Parameters from config
COIN_PAIRS = config["coin_pairs"]  # Example: ["BTC/USDT", "ETH/USDT"]
INVESTMENT_INCREMENT = config["investment_increment"]
DAILY_MAX_INVESTMENT = config["daily_max_investment"]
DAILY_MAX_ENTRIES = 5
PRICE_DROP_PERCENTAGES = config["price_drop_levels"]  # List of drop levels (e.g., [1, 2, 3, 4, 5])
AUTO_PROFIT_ON = config.get("auto_profit_on", True)
AUTO_PROFIT_PERCENTAGE = config.get("auto_profit_percentage", 5)
ORDER_TYPE = config["order_type"]

# Global variables to track multiple pairs
pair_data = {
    pair: {
        "current_investment": INVESTMENT_INCREMENT,
        "daily_entries": 0,
        "total_quantity": 0,
        "total_cost": 0,
        "drop_triggers": {level: False for level in PRICE_DROP_PERCENTAGES},
        "previous_day_price": None,
        "last_buy": False,  # Tracks if a new entry occurred since the last sell
        "skipped_days": 0  # Tracks days without any trades
    }
    for pair in COIN_PAIRS
}

IST = pytz.timezone('Asia/Kolkata')  # Timezone for IST

# Helper Functions
def fetch_current_price(pair):
    """Fetch the latest price of a specific coin pair."""
    logging.debug(f"Entering fetch_current_price() for {pair}")
    try:
        ticker = exchange.fetch_ticker(pair)
        logging.info(f"Fetched current price for {pair}: {ticker['last']}")
        return ticker['last']
    except Exception as e:
        logging.error(f"Error fetching current price for {pair}: {e}")
        return None
    finally:
        logging.debug(f"Exiting fetch_current_price() for {pair}")

def convert_usdt_to_btc(pair, usdt_amount):
    """Convert USDT to BTC for a specific pair."""
    logging.debug(f"Entering convert_usdt_to_btc() for {pair}")
    data = pair_data[pair]

    # Determine the scaled amount for the first entry
    if data["daily_entries"] == 0:
        scale_factor = min(data["skipped_days"] + 1, 5)  # Scale factor capped at 5
        scaled_amount = usdt_amount * scale_factor
        logging.info(f"First entry for {pair} today. Scaled investment amount: {scaled_amount} USDT.")
    else:
        scaled_amount = usdt_amount  # Use regular amount for subsequent entries

    # Check daily entry limit
    if data["daily_entries"] >= DAILY_MAX_ENTRIES:
        logging.warning(f"Daily buy limit reached for {pair}. Skipping conversion.")
        return None

    try:
        current_price = fetch_current_price(pair)
        if current_price is None:
            logging.warning(f"Unable to fetch current price for {pair}. Skipping conversion.")
            return None

        btc_quantity = scaled_amount / current_price
        if btc_quantity < 0.00001:
            logging.warning(f"Buy quantity {btc_quantity:.8f} is below the minimum required for {pair}. Skipping.")
            return None

        order = exchange.create_market_buy_order(pair, btc_quantity)
        if order:
            data["total_quantity"] += order["filled"]
            data["total_cost"] += order["filled"] * current_price
            data["daily_entries"] += 1
            data["last_buy"] = True  # Mark that a new entry has occurred

            # Reset skipped_days after the first entry of the day
            if data["daily_entries"] == 1:
                data["skipped_days"] = 0
                logging.info(f"Reset skipped_days to 0 for {pair} after the first trade today.")

            logging.info(f"Conversion successful for {pair}: Bought {order['filled']} at {current_price}.")
            return order
    except Exception as e:
        logging.error(f"Error during USDT to BTC conversion for {pair}: {e}")
        return None
    finally:
        logging.debug(f"Exiting convert_usdt_to_btc() for {pair}")

def sell_btc_binance(pair, quantity_to_sell):
    """Sell BTC on Binance Spot for a specific pair."""
    logging.debug(f"Entering sell_btc_binance() for {pair}")
    data = pair_data[pair]

    try:
        current_price = fetch_current_price(pair)
        if current_price is None:
            logging.warning(f"Unable to fetch current price for {pair}. Skipping sell order.")
            return None

        if quantity_to_sell < 0.00001:
            logging.warning(f"Sell quantity {quantity_to_sell:.8f} is below the minimum required for {pair}. Skipping.")
            return None

        order = exchange.create_market_sell_order(pair, quantity_to_sell)
        if order:
            data["total_quantity"] -= order["filled"]
            data["total_cost"] -= order["filled"] * (data["total_cost"] / data["total_quantity"])
            data["last_buy"] = False  # Reset flag after a successful sell
            logging.info(f"Sold {order['filled']} of {pair} at {current_price}.")
            return order
    except Exception as e:
        logging.error(f"Error during BTC sell for {pair}: {e}")
        return None
    finally:
        logging.debug(f"Exiting sell_btc_binance() for {pair}")

# Trading Logic
def check_daily_drop(pair):
    """Check price drops and buy for the specific coin pair."""
    data = pair_data[pair]
    try:
        if data["daily_entries"] >= DAILY_MAX_ENTRIES:
            logging.info(f"Daily entry limit reached for {pair}. Skipping further checks.")
            return

        if not data["previous_day_price"]:
            logging.warning(f"Previous day price not available for {pair}. Skipping drop check.")
            return

        current_price = fetch_current_price(pair)
        if current_price is None:
            logging.warning(f"Unable to fetch current price for {pair}. Skipping drop check.")
            return

        for drop_level in PRICE_DROP_PERCENTAGES:
            drop_value = data["previous_day_price"] * (1 - drop_level / 100)
            if not data["drop_triggers"][drop_level] and current_price <= drop_value:
                usdt_to_invest = min(data["current_investment"], DAILY_MAX_INVESTMENT)
                logging.info(f"Price dropped by {drop_level}% for {pair}. Investing {usdt_to_invest} USDT.")
                convert_usdt_to_btc(pair, usdt_to_invest)
                data["drop_triggers"][drop_level] = True
                break
    except Exception as e:
        logging.error(f"Error in check_daily_drop for {pair}: {e}")

def check_auto_profit(pair):
    """Check if auto-profit conditions are met for a specific pair."""
    data = pair_data[pair]
    try:
        # Skip if no new buy has occurred since the last sell
        if not data["last_buy"]:
            logging.info(f"No new entry for {pair} since last sell. Skipping auto-profit check.")
            return

        current_price = fetch_current_price(pair)
        if current_price is None:
            logging.warning(f"Unable to fetch current price for {pair}. Skipping auto-profit check.")
            return

        avg_price = data["total_cost"] / data["total_quantity"] if data["total_quantity"] > 0 else 0
        if AUTO_PROFIT_ON and current_price >= avg_price * (1 + AUTO_PROFIT_PERCENTAGE / 100):
            quantity_to_sell = data["total_quantity"] * 0.5  # Sell 50% of the holdings
            logging.info(f"Auto-profit triggered for {pair}. Selling 50%.")
            sell_btc_binance(pair, quantity_to_sell)
    except Exception as e:
        logging.error(f"Error in check_auto_profit for {pair}: {e}")

def reset_daily_investment():
    """Reset daily trading variables for all pairs."""
    for pair in COIN_PAIRS:
        data = pair_data[pair]
        try:
            current_price = fetch_current_price(pair)
            if current_price:
                data["previous_day_price"] = current_price
                logging.info(f"Updated previous day's price to {current_price} for {pair}.")
            else:
                logging.warning(f"Unable to fetch current price for {pair}. Retaining previous day's price.")

            # Increment skipped_days if no entries were made
            if data["daily_entries"] == 0:
                data["skipped_days"] += 1
                logging.info(f"No trades made for {pair} today. Incrementing skipped_days to {data['skipped_days']}.")

            # Reset daily-specific variables
            data["daily_entries"] = 0
            data["drop_triggers"] = {level: False for level in PRICE_DROP_PERCENTAGES}
        except Exception as e:
            logging.error(f"Error in reset_daily_investment for {pair}: {e}")

# Scheduler setup for multiple pairs
scheduler = Scheduler()
for pair in COIN_PAIRS:
    scheduler.every(1).minutes.do(check_daily_drop, pair)
    scheduler.every(1).minutes.do(check_auto_profit, pair)

scheduler.every().day.at("23:55").do(reset_daily_investment)

# Main Loop
if __name__ == "__main__":
    try:
        while True:
            scheduler.run_pending()
            time.sleep(1)
    except KeyboardInterrupt:
        logging.warning("Bot stopped by user.")
    except Exception as e:
        logging.critical(f"Unexpected error: {e}")
